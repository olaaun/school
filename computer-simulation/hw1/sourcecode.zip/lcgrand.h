float lcgrand(int stream);
void lcgrandst(long zset, int stream);
long lcgrandgt(int stream);
